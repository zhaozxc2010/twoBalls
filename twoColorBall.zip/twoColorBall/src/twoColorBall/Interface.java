package twoColorBall;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import util.Util;

public class Interface extends JFrame{
	public int width  = 400;
	public int height = 600;
	
	public static String redCount; 
	public static String blueCount; 
	public static String count; 
	
	JPanel jp1,jp2,jp3,jp4;//һ�����
	JSplitPane jsplit;//������
	JScrollPane jsp;//���������
	JLabel jl1,jl2,jl3,jl4;//��ǩ
	JComboBox jcb1,jcb2,jcb3;//�����˵�
	JTextField jtf;//�ı���
	JRadioButton jrb1,jrb2;//��ѡ��ť
	ButtonGroup bg;//��ѡ��ť���
	JButton jb;
	JTextArea jta;//�����ı���
	public static void main(String[] args) {
		Interface i = new Interface();
	}
	public Interface(){
		super("˫ɫ��");
		jl1 = new JLabel("    ���������");
		jl2 = new JLabel("    ���������");
//		jl3 = new JLabel("");
//		jl3.setLayout(new FlowLayout(FlowLayout.LEFT));
//		jl4 = new JLabel("");
//		jl4.setLayout(new FlowLayout(FlowLayout.LEFT));
		String[] red = Util.getStrArray(6,28);
		jcb1 = new JComboBox(red);
		String[] blue = Util.getStrArray(1,16);
		jcb2 = new JComboBox(blue);
		String[] count = {"1","2","3","4","5","10","15","20","50","100"};
		jcb3 = new JComboBox(count);
		
		jrb1 = new JRadioButton("ע    ����",true);
		jrb2 = new JRadioButton("��дע����");
		jtf = new JTextField();
		bg = new ButtonGroup();
		bg.add(jrb1);
		bg.add(jrb2);
		jb = new JButton("���ɲ�Ʊ");
		jb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String redCount = (String) jcb1.getSelectedItem();//�������
				String blueCount = (String) jcb2.getSelectedItem();//��������
				String count = "";
				TwoColorBall tcb = new TwoColorBall();
				if(jrb1.getSelectedObjects() != null){
					count = (String) jcb3.getSelectedItem();//ע��
					String numbers = tcb.getManyNumbers(redCount, blueCount, count);
					jta.setText(numbers);
				}else{
					if(jtf.getText()!=null && !"".equals(jtf.getText())){
						count = jtf.getText();//�ֶ�¼��ע��
						int num = Integer.valueOf(count); 
						
						String numbers = tcb.getManyNumbers(redCount, blueCount, count);
						jta.setText(numbers);
					}else{
						JOptionPane.showMessageDialog(null, "ע������Ϊ�գ�", "ע��", JOptionPane.WARNING_MESSAGE);
					}
				}
			}
		});
		jp1 = new JPanel(new GridLayout(2,2));
		jp4 = new JPanel(new GridLayout(2,2));
		jp2 = new JPanel(new FlowLayout(FlowLayout.CENTER));
		jp3 = new JPanel(new GridLayout(3,1,0,5));
		
		
		jp1.add(jl1);
		jp1.add(jcb1);
		jp1.add(jl2);
		jp1.add(jcb2);
		
		jp4.add(jrb1);
//		jp4.add(jl3);
		jp4.add(jcb3);
		jp4.add(jrb2);
//		jp4.add(jl4);
		jp4.add(jtf);
		//��ť
		jp2.add(jb);
		//�ϰ벿��
		jp3.add(jp1);
		jp3.add(jp4);
		jp3.add(jp2);
		
		//�°벿�ֵ��ı���
		jta = new JTextArea();
		jsp = new JScrollPane(jta);
		//�ָ���壬������jp3,������jsp
		jsplit = new JSplitPane(JSplitPane.VERTICAL_SPLIT,jp3,jsp);
		getContentPane().add(jsplit);
		//this.setLayout(new GridLayout(2,1,5,5));//�ĸ�������2�У�1�У�ˮƽ��࣬��ֱ���
		this.setResizable(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//���õ�����ر�ʱ���Ƴ��������
		this.setSize(width, height);
		this.setLocation(Util.getWindowCenterWidth(width), Util.getWindowCenterHeight(height));
		this.setIconImage(new ImageIcon("images/icon.png").getImage());
		this.setVisible(true);
	}
}
